<header>
  <nav>
    <ul>
      <li><a href="index.html">Home</li>
      <li><a href="about.html">About</li>
      <li><a href="artwork.html">Artwork</li>
      <li><a href="resume.html">Resume</li>
    </ul>
  </nav>
</header>
  <div class="container">
    <h1>Sorry something went wrong with your submission</h1>
    <p>Please try again</p>
  </div>
